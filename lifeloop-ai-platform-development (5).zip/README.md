# LifeLoop AI — Community Problem Intelligence Website

> *"Small actions. Smart intelligence. Better tomorrow."*

LifeLoop AI is a responsive fullstack **website application** built with **Next.js (App Router), React, TypeScript, Tailwind CSS, Drizzle ORM, and PostgreSQL**. It works seamlessly in desktop and mobile browsers (with camera upload, voice-to-report, geolocation, and a Web App Manifest) — no native app installation required.

---

## Features
- **AI Problem Scanner (`/report`)** — Upload a photo (or test with demo frames), speak via browser voice-to-report, or write in 6 languages (`EN`, `HI`, `ES`, `FR`, `SW`, `AR`). AI predicts the category, confidence score, priority band, practical next steps, and nearby duplicates — with full human override controls.
- **Shared Community Dashboard (`/dashboard`)** — Live stats, 14-day trend chart, neighbourhood load, search, status/category filters, and grouped duplicate threads.
- **Actionable Report Threads (`/reports/[id]`)** — Support & community verification, status workflow (`open → in_progress → resolved`), human category corrections, action timeline, and AI transparency panel.
- **Community Problem Heatmap (`/heatmap`)** — Interactive neighbourhood hotspot visualization and category density rankings.
- **Green Impact Points (`/impact`)** — Community leaderboard, contribution tiers, resolution trends, and transparent scoring rules.

---

## 1. Push to GitHub

Unzip the archive, open a terminal inside `lifeloop-ai-website/`, and push to a new GitHub repository:

```bash
unzip lifeloop-ai-website.zip
cd lifeloop-ai-website
git init
git add .
git commit -m "Initial commit: LifeLoop AI website"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO>.git
git push -u origin main
```

---

## 2. Deploy on Vercel (Recommended)

1. Sign in to [Vercel](https://vercel.com) and click **Add New… → Project**.
2. Import your GitHub repository (`<YOUR_USERNAME>/<YOUR_REPO>`).
   - Vercel automatically detects **Next.js** and uses **`vercel.json`**.
3. Attach a free PostgreSQL database:
   - In your Vercel project, go to **Storage → Create Database → Neon (Postgres)** (or Supabase Postgres) and connect it — Vercel injects `DATABASE_URL` / `POSTGRES_URL` automatically.
   - Or paste any PostgreSQL URL into **Settings → Environment Variables** as `DATABASE_URL`.
4. Click **Deploy**.
   - Tables and initial demo data (8 residents + 25 realistic reports) bootstrap automatically on the first visit.

---

## 3. Deploy on Render (Alternative)

1. Sign in to [Render](https://dashboard.render.com) → **New + → Blueprint**.
2. Select your GitHub repository.
3. Render reads **`render.yaml`** and provisions both **PostgreSQL** (`lifeloop-db`) and the **Node.js Web Service** (`lifeloop-ai`). Click **Apply**.

---

## 4. Run Locally

```bash
cp .env.example .env
# Update DATABASE_URL in .env if needed
npm install
npm run dev
```

Open `http://localhost:3000`.
