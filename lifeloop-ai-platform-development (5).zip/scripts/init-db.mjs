import "dotenv/config";
import pg from "pg";

const { Pool } = pg;

const databaseUrl =
  process.env.DATABASE_URL ||
  process.env.POSTGRES_URL ||
  process.env.POSTGRES_PRISMA_URL ||
  process.env.POSTGRES_URL_NON_POOLING;
if (!databaseUrl) {
  console.error("DATABASE_URL (or POSTGRES_URL) is not set. Skipping database initialization.");
  process.exit(1);
}

function shouldUseSsl(url) {
  if (process.env.DATABASE_SSL === "false") return false;
  if (process.env.DATABASE_SSL === "true") return true;
  if (url.includes("sslmode=require") || url.includes("sslmode=verify-")) return true;
  try {
    const host = new URL(url).hostname.toLowerCase();
    return !(
      host === "localhost" ||
      host === "127.0.0.1" ||
      host === "::1" ||
      host.endsWith(".local")
    );
  } catch {
    return false;
  }
}

const pool = new Pool({
  connectionString: databaseUrl,
  ssl: shouldUseSsl(databaseUrl) ? { rejectUnauthorized: false } : undefined,
});

const statements = [
  `CREATE TABLE IF NOT EXISTS users (
    id serial PRIMARY KEY,
    name text NOT NULL,
    handle text NOT NULL UNIQUE,
    neighbourhood text NOT NULL,
    role text NOT NULL DEFAULT 'Resident',
    tone text NOT NULL DEFAULT 'emerald',
    points integer NOT NULL DEFAULT 0,
    reports_count integer NOT NULL DEFAULT 0,
    resolved_count integer NOT NULL DEFAULT 0,
    created_at timestamptz NOT NULL DEFAULT now()
  );`,
  `CREATE TABLE IF NOT EXISTS reports (
    id serial PRIMARY KEY,
    reference text NOT NULL,
    reporter_id integer REFERENCES users(id) ON DELETE SET NULL,
    title text NOT NULL,
    description text NOT NULL,
    language text NOT NULL DEFAULT 'en',
    category text NOT NULL,
    ai_category text NOT NULL,
    ai_confidence real NOT NULL DEFAULT 0.7,
    priority text NOT NULL DEFAULT 'medium',
    priority_score integer NOT NULL DEFAULT 50,
    priority_reason text NOT NULL DEFAULT '',
    status text NOT NULL DEFAULT 'open',
    neighbourhood text NOT NULL,
    address text NOT NULL DEFAULT '',
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    image_url text,
    ai_summary text NOT NULL DEFAULT '',
    tags jsonb NOT NULL DEFAULT '[]'::jsonb,
    recommendations jsonb NOT NULL DEFAULT '[]'::jsonb,
    signals jsonb,
    duplicate_candidates jsonb NOT NULL DEFAULT '[]'::jsonb,
    responsible_department text NOT NULL DEFAULT '',
    expected_response text NOT NULL DEFAULT '',
    duplicate_of_id integer,
    duplicate_count integer NOT NULL DEFAULT 0,
    upvotes integer NOT NULL DEFAULT 0,
    verifications integer NOT NULL DEFAULT 0,
    category_corrected boolean NOT NULL DEFAULT false,
    model_version text NOT NULL DEFAULT 'lifeloop-vision-2.1',
    impact_points integer NOT NULL DEFAULT 0,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    resolved_at timestamptz
  );`,
  `CREATE UNIQUE INDEX IF NOT EXISTS reports_reference_idx ON reports(reference);`,
  `CREATE INDEX IF NOT EXISTS reports_status_idx ON reports(status);`,
  `CREATE INDEX IF NOT EXISTS reports_category_idx ON reports(category);`,
  `CREATE TABLE IF NOT EXISTS report_updates (
    id serial PRIMARY KEY,
    report_id integer NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    user_id integer REFERENCES users(id) ON DELETE SET NULL,
    kind text NOT NULL DEFAULT 'note',
    from_status text,
    to_status text,
    note text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
  );`,
  `CREATE INDEX IF NOT EXISTS report_updates_report_idx ON report_updates(report_id);`,
  `CREATE TABLE IF NOT EXISTS report_votes (
    id serial PRIMARY KEY,
    report_id integer NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind text NOT NULL DEFAULT 'upvote',
    created_at timestamptz NOT NULL DEFAULT now()
  );`,
  `CREATE UNIQUE INDEX IF NOT EXISTS report_votes_unique_idx ON report_votes(report_id, user_id, kind);`,
];

try {
  for (const sqlText of statements) {
    await pool.query(sqlText);
  }
  console.log("LifeLoop AI PostgreSQL schema is ready.");
} catch (error) {
  console.error("Failed to initialize database schema:", error);
  process.exitCode = 1;
} finally {
  await pool.end();
}
