import {
  createReport,
  getAllReports,
  getLeaderboard,
  getPlatformStats,
} from "@/lib/data";
import { ensureSeeded } from "@/lib/seed";
import { getCurrentUser } from "@/lib/session";
import { CATEGORIES, type CategoryId, type Priority } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    const [reports, leaders, currentUser] = await Promise.all([
      getAllReports(),
      getLeaderboard(),
      getCurrentUser(),
    ]);
    const stats = await getPlatformStats(reports, leaders);
    return Response.json({ reports, stats, leaders, currentUser });
  } catch {
    return Response.json(
      { error: "Could not load community reports." },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureSeeded();
    const body = (await request.json()) as Record<string, unknown>;
    const description = typeof body.description === "string" ? body.description.trim() : "";
    const title = typeof body.title === "string" ? body.title.trim() : "";

    if (description.length < 8) {
      return Response.json(
        { error: "Please describe the problem in at least a few words." },
        { status: 400 },
      );
    }

    const user = await getCurrentUser();
    const categoryOverride =
      typeof body.category === "string" &&
      CATEGORIES.some((category) => category.id === body.category)
        ? (body.category as CategoryId)
        : null;
    const priorityOverride =
      body.priority === "low" || body.priority === "medium" || body.priority === "high"
        ? (body.priority as Priority)
        : null;

    const imageUrl =
      typeof body.imageUrl === "string" && body.imageUrl.length < 1_800_000 ? body.imageUrl : null;

    const result = await createReport({
      title: title || description.slice(0, 80),
      description,
      language: typeof body.language === "string" ? body.language : "en",
      neighbourhood: typeof body.neighbourhood === "string" ? body.neighbourhood : "Old Town",
      address: typeof body.address === "string" ? body.address : undefined,
      lat: typeof body.lat === "number" ? body.lat : undefined,
      lng: typeof body.lng === "number" ? body.lng : undefined,
      imageSampleKey: typeof body.imageSampleKey === "string" ? body.imageSampleKey : null,
      imageFeatures:
        body.imageFeatures && typeof body.imageFeatures === "object"
          ? (body.imageFeatures as {
              brightness: number;
              saturation: number;
              greenness: number;
              grayness: number;
            })
          : null,
      imageUrl,
      reporterId: user.id,
      categoryOverride,
      priorityOverride,
      duplicateOfId: typeof body.duplicateOfId === "number" ? body.duplicateOfId : null,
    });

    return Response.json({
      id: result.id,
      reference: result.reference,
      analysis: result.analysis,
    });
  } catch {
    return Response.json(
      { error: "We could not save the report. Please try again." },
      { status: 500 },
    );
  }
}
