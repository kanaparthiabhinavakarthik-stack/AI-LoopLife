import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { SESSION_COOKIE } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    await ensureSeeded();
    const body = (await request.json()) as { userId?: number };
    const userId = Number(body.userId);
    if (!Number.isFinite(userId)) {
      return Response.json({ error: "Invalid member" }, { status: 400 });
    }
    const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!user) return Response.json({ error: "Member not found" }, { status: 404 });

    const store = await cookies();
    store.set(SESSION_COOKIE, String(user.id), {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 30,
    });
    return Response.json({ ok: true, user: { id: user.id, name: user.name } });
  } catch {
    return Response.json({ error: "Could not switch member" }, { status: 500 });
  }
}
