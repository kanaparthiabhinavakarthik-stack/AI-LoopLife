import { readFile, stat } from "node:fs/promises";
import path from "node:path";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const ZIP_PATH = path.join(
  process.cwd(),
  "public",
  "downloads",
  "lifeloop-ai-website.zip",
);

export async function GET(request: Request) {
  try {
    const info = await stat(ZIP_PATH);
    const buffer = await readFile(ZIP_PATH);
    return new Response(buffer, {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="lifeloop-ai-website.zip"',
        "Content-Length": String(info.size),
        "Cache-Control": "no-store",
      },
    });
  } catch {
    // Fallback for serverless platforms (like Vercel) where public/ is served from CDN edge.
    const staticUrl = new URL("/downloads/lifeloop-ai-website.zip", request.url);
    return Response.redirect(staticUrl, 302);
  }
}
