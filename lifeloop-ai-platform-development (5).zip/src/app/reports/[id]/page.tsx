/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { notFound } from "next/navigation";
import ReportActions from "@/components/ReportActions";
import {
  Avatar,
  CategoryGlyph,
  ConfidenceMeter,
  PriorityBadge,
  StatusBadge,
} from "@/components/ui";
import { getReportDetail } from "@/lib/data";
import { ensureSeeded } from "@/lib/seed";
import {
  NEIGHBOURHOODS,
  PRIORITY_META,
  categoryMeta,
  type ReportStatus,
} from "@/lib/types";

export const dynamic = "force-dynamic";

function formatDate(iso: string): string {
  return new Intl.DateTimeFormat("en-GB", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(iso));
}

export default async function ReportDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ new?: string }>;
}) {
  await ensureSeeded();
  const { id } = await params;
  const query = await searchParams;
  const reportId = Number(id);
  if (!Number.isFinite(reportId)) notFound();

  const detail = await getReportDetail(reportId);
  if (!detail) notFound();

  const { report, updates, related } = detail;
  const meta = categoryMeta(report.category);
  const aiMeta = categoryMeta(report.aiCategory);
  const hood = NEIGHBOURHOODS.find((item) => item.name === report.neighbourhood) ?? NEIGHBOURHOODS[0];
  const groupedThread = related.filter(
    (item) => item.duplicateOfId != null || item.duplicateCount > 0,
  );

  return (
    <div className="mx-auto max-w-[1180px] px-4 py-6 sm:px-6 sm:py-8">
      <Link
        href="/dashboard"
        className="inline-flex items-center gap-1.5 text-[12px] font-semibold text-ink/50 hover:text-forest"
      >
        <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
          <path d="M19 12H5M11 6l-6 6 6 6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        Community dashboard
      </Link>

      {query.new === "1" && (
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-lime bg-lime-soft/70 px-4 py-3">
          <p className="text-[12px] font-semibold text-forest">
            Report published. AI analysis, duplicate check and recommendations are attached below.
          </p>
          <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-forest/70">
            +10 impact points earned
          </span>
        </div>
      )}

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className="rounded-full border border-line bg-paper px-2.5 py-1 font-mono text-[9px] uppercase tracking-[0.14em] text-ink/50">
          {report.reference}
        </span>
        <StatusBadge status={report.status} />
        <PriorityBadge priority={report.priority} score={report.priorityScore} />
        <span className="inline-flex items-center gap-1.5 rounded-full border border-line bg-paper px-2.5 py-1 text-[11px] font-medium text-ink/70">
          <CategoryGlyph category={report.category} className="h-3.5 w-3.5" />
          {meta.label}
        </span>
        {report.duplicateCount > 0 && (
          <span className="rounded-full border border-forest/30 bg-lime-soft px-2.5 py-1 text-[10px] font-semibold text-forest">
            grouped thread · {report.duplicateCount + 1} reports
          </span>
        )}
        {report.categoryCorrected && (
          <span className="rounded-full border border-amber-200 bg-amber-50 px-2.5 py-1 text-[10px] font-medium text-amber-800">
            human-corrected from {aiMeta.short}
          </span>
        )}
      </div>

      <h1 className="display mt-3 max-w-3xl text-[30px] leading-[1.05] sm:text-[40px]">
        {report.title}
      </h1>

      <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-[11.5px] text-ink/50">
        <span className="inline-flex items-center gap-2">
          <Avatar name={report.reporterName ?? "Neighbour"} tone={report.reporterTone} size="sm" />
          <span>
            Reported by{" "}
            <span className="font-semibold text-ink/75">{report.reporterName ?? "a neighbour"}</span>
          </span>
        </span>
        <span className="inline-flex items-center gap-1.5">
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={1.7} aria-hidden>
            <path d="M12 21s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11Z" />
            <circle cx="12" cy="10" r="2.5" />
          </svg>
          {report.address || report.neighbourhood} · {report.neighbourhood}
        </span>
        <span>{formatDate(report.createdAt)}</span>
        <span className="font-mono text-[10px] uppercase tracking-[0.1em]">
          {report.language.toUpperCase()} · {report.modelVersion}
        </span>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[1.28fr_0.72fr]">
        <div className="space-y-4">
          <div className="relative overflow-hidden rounded-[22px] border border-line bg-moss">
            {report.imageUrl ? (
              <img
                src={report.imageUrl}
                alt={report.title}
                className="h-[300px] w-full object-cover sm:h-[380px]"
              />
            ) : (
              <div className="grid-paper h-[300px] w-full bg-mist" />
            )}
            {query.new === "1" && <div className="scan-frame absolute inset-0" />}
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/90 via-ink/30 to-transparent p-4">
              <div className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-lime">
                    AI predicted
                  </p>
                  <p className="mt-1 flex items-center gap-2 text-[15px] font-semibold text-paper">
                    <CategoryGlyph category={report.aiCategory} className="h-4 w-4 text-lime" />
                    {aiMeta.label}
                  </p>
                </div>
                <div className="min-w-[130px] rounded-lg bg-paper/95 px-3 py-2 backdrop-blur">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[8.5px] uppercase tracking-[0.12em] text-ink/45">
                      confidence
                    </span>
                    <span className="font-mono text-[11px] font-semibold text-forest">
                      {Math.round(report.aiConfidence * 100)}%
                    </span>
                  </div>
                  <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-mist">
                    <div
                      className="h-full rounded-full bg-forest"
                      style={{ width: `${report.aiConfidence * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-[22px] border border-line bg-paper p-5">
            <p className="mono-label">What was reported</p>
            <p className="mt-2 text-[13.5px] leading-relaxed text-ink/75">{report.description}</p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {report.tags.map((tag) => (
                <span key={tag} className="rounded-full border border-line bg-bone/60 px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.08em] text-ink/50">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div className="rounded-[22px] border border-line bg-paper p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="mono-label">AI analysis</p>
              <span className="font-mono text-[9px] uppercase tracking-[0.1em] text-ink/35">
                suggestion, not a verified fact
              </span>
            </div>
            <p className="mt-3 rounded-xl bg-mist/60 p-3 text-[12.5px] leading-relaxed text-ink/70">
              {report.aiSummary}
            </p>
            <p className="mt-2 text-[11.5px] leading-relaxed text-ink/50">{report.priorityReason}</p>

            {report.signals && (
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-ink/40">
                    Text signals
                  </p>
                  <div className="mt-2 space-y-1.5">
                    {report.signals.text.length === 0 && (
                      <p className="text-[11px] text-ink/40">Text model deferred to vision.</p>
                    )}
                    {report.signals.text.map((signal) => (
                      <div key={signal.label} className="flex items-center gap-2">
                        <span className="w-16 shrink-0 truncate text-[10.5px] text-ink/60">{signal.label}</span>
                        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-mist">
                          <div className="h-full rounded-full bg-forest/80" style={{ width: `${signal.weight}%` }} />
                        </div>
                        <span className="w-7 text-right font-mono text-[9px] text-ink/40">{signal.weight}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-ink/40">
                    Vision signals
                  </p>
                  <div className="mt-2 space-y-1.5">
                    {report.signals.vision.length === 0 && (
                      <p className="text-[11px] text-ink/40">No image supplied for this report.</p>
                    )}
                    {report.signals.vision.map((signal) => (
                      <div key={signal.label} className="flex items-center gap-2">
                        <span className="w-16 shrink-0 truncate text-[10.5px] text-ink/60">{signal.label}</span>
                        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-mist">
                          <div className="h-full rounded-full bg-leaf" style={{ width: `${signal.weight}%` }} />
                        </div>
                        <span className="w-7 text-right font-mono text-[9px] text-ink/40">{signal.weight}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {report.signals?.severity.length ? (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {report.signals.severity.map((item) => (
                  <span key={item} className="rounded-full bg-rose-50 px-2 py-0.5 text-[9.5px] font-medium text-rose-700">
                    {item}
                  </span>
                ))}
              </div>
            ) : null}
          </div>

          <div className="rounded-[22px] border border-line bg-paper p-5">
            <p className="mono-label">Recommended next steps</p>
            <div className="mt-3 space-y-2">
              {report.recommendations.map((recommendation, index) => (
                <div key={recommendation.title} className="flex gap-3 rounded-xl border border-line bg-bone/40 p-3">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-forest font-mono text-[9px] text-lime">
                    {index + 1}
                  </span>
                  <div>
                    <p className="text-[12px] font-semibold">{recommendation.title}</p>
                    <p className="mt-0.5 text-[11.5px] leading-relaxed text-ink/55">{recommendation.detail}</p>
                    <p className="mt-1 font-mono text-[9px] uppercase tracking-[0.1em] text-forest/70">
                      owner · {recommendation.owner}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {groupedThread.length > 0 && (
            <div className="rounded-[22px] border border-forest/25 bg-lime-soft/40 p-5">
              <div className="flex items-center justify-between">
                <p className="mono-label !text-forest">Duplicate intelligence · grouped reports</p>
                <span className="rounded-full bg-forest px-2 py-0.5 font-mono text-[9px] text-lime">
                  {groupedThread.length} linked
                </span>
              </div>
              <p className="mt-1.5 text-[11px] leading-relaxed text-forest/80">
                Similar wording, category and location grouped these reports into one thread. Each
                resident still receives credit for their evidence.
              </p>
              <div className="mt-3 space-y-1.5">
                {groupedThread.map((item) => (
                  <Link
                    key={item.id}
                    href={`/reports/${item.id}`}
                    className="flex items-center gap-3 rounded-xl border border-forest/15 bg-paper/80 px-3 py-2 transition hover:border-forest/40"
                  >
                    <span className="font-mono text-[9px] text-ink/40">{item.reference}</span>
                    <span className="min-w-0 flex-1 truncate text-[11.5px] font-medium text-ink/75">
                      {item.title}
                    </span>
                    <span className="hidden text-[10px] text-ink/40 sm:block">{item.reporterName}</span>
                    <StatusBadge status={item.status} />
                  </Link>
                ))}
              </div>
            </div>
          )}

          <div className="rounded-[22px] border border-line bg-paper p-5">
            <div className="flex items-center justify-between">
              <p className="mono-label">Action trail</p>
              <span className="font-mono text-[9px] uppercase tracking-[0.1em] text-ink/35">
                {updates.length} events
              </span>
            </div>
            <ol className="mt-4 space-y-4">
              {updates.map((update, updateIndex) => (
                <li key={update.id} className="relative pl-6">
                  <span className="absolute left-0 top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full border border-forest/25 bg-lime-soft">
                    <span className="h-1.5 w-1.5 rounded-full bg-forest" />
                  </span>
                  {updateIndex < updates.length - 1 && (
                    <span className="absolute left-[6.5px] top-5 h-[calc(100%-2px)] w-px bg-line" />
                  )}
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-full border border-line bg-bone/60 px-2 py-0.5 font-mono text-[8.5px] uppercase tracking-[0.1em] text-ink/45">
                      {update.kind}
                    </span>
                    <span className="text-[10px] text-ink/40">{formatDate(update.createdAt)}</span>
                    <span className="text-[10px] font-medium text-ink/55">{update.actorName}</span>
                  </div>
                  <p className="mt-1 text-[12px] leading-relaxed text-ink/70">{update.note}</p>
                </li>
              ))}
            </ol>
          </div>
        </div>

        <aside className="space-y-3">
          <ReportActions
            reportId={report.id}
            status={report.status as ReportStatus}
            category={report.category}
            upvotes={report.upvotes}
            verifications={report.verifications}
            reporterName={report.reporterName}
            points={report.impactPoints}
          />

          <div className="rounded-[22px] border border-line bg-moss p-4 text-paper">
            <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-lime">AI snapshot</p>
            <div className="mt-3 space-y-2.5">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10.5px] text-paper/55">Priority score</span>
                  <span className="font-mono text-[11px] text-lime">{report.priorityScore}/100</span>
                </div>
                <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/10">
                  <div
                    className="h-full rounded-full bg-lime"
                    style={{ width: `${report.priorityScore}%` }}
                  />
                </div>
                <p className="mt-1 text-[10px] leading-relaxed text-paper/50">
                  {PRIORITY_META[report.priority].hint}
                </p>
              </div>
              <div className="flex items-center justify-between border-t border-white/10 pt-2.5">
                <span className="text-[10.5px] text-paper/55">Suggested route</span>
                <span className="max-w-[58%] text-right text-[10.5px] font-medium">
                  {report.responsibleDepartment}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10.5px] text-paper/55">Response guide</span>
                <span className="text-[10.5px] font-medium text-lime">{report.expectedResponse}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10.5px] text-paper/55">Category confidence</span>
                <span className="text-[10.5px] font-medium">{Math.round(report.aiConfidence * 100)}%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10.5px] text-paper/55">Thread impact</span>
                <span className="text-[10.5px] font-medium text-lime">{report.impactPoints} pts</span>
              </div>
            </div>
            <p className="mt-3 border-t border-white/10 pt-2.5 text-[9.5px] leading-relaxed text-paper/40">
              {report.signals?.reasoning ?? "Model output is advisory. Human review overrides AI predictions."}
            </p>
          </div>

          <div className="rounded-[22px] border border-line bg-paper p-4">
            <p className="mono-label">Location</p>
            <div className="relative mt-2 h-[150px] overflow-hidden rounded-xl border border-line bg-bone">
              <div className="grid-paper absolute inset-0 opacity-80" />
              <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full" aria-hidden>
                <path d="M0 66 C20 58 30 74 46 70 C62 66 70 84 88 76 L100 70 L100 100 L0 100 Z" fill="#cfe4d6" opacity="0.8" />
                <path d="M4 38 H96M28 6 V72M64 6 V72" stroke="#0d1f18" strokeOpacity="0.07" strokeWidth="0.6" />
              </svg>
              <div
                className="absolute -translate-x-1/2 -translate-y-1/2"
                style={{ left: `${hood.x}%`, top: `${hood.y}%` }}
              >
                <span className="absolute -inset-4 rounded-full bg-forest/15" />
                <span className="relative flex h-4 w-4 items-center justify-center rounded-full border-2 border-paper bg-forest shadow">
                  <span className="h-1 w-1 rounded-full bg-lime" />
                </span>
              </div>
              <span className="absolute bottom-2 left-2 rounded bg-paper/90 px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-[0.1em] text-ink/50">
                {hood.name} · {report.lat.toFixed(4)}, {report.lng.toFixed(4)}
              </span>
            </div>
            <p className="mt-2 text-[11px] text-ink/55">{report.address || report.neighbourhood}</p>
            <Link href="/heatmap" className="mt-1 inline-flex text-[10.5px] font-semibold text-forest hover:underline">
              See neighbourhood heatmap →
            </Link>
          </div>

          <div className="rounded-[22px] border border-line bg-paper p-4">
            <p className="mono-label">Model transparency</p>
            <div className="mt-2 space-y-1.5 text-[10.5px] leading-relaxed text-ink/55">
              <p>
                <span className="font-semibold text-ink">Model:</span> {report.modelVersion} (text +
                vision fusion)
              </p>
              <p>
                <span className="font-semibold text-ink">AI predicted:</span> {aiMeta.label}{" "}
                ({Math.round(report.aiConfidence * 100)}%)
              </p>
              <p>
                <span className="font-semibold text-ink">Published category:</span> {meta.label}
                {report.categoryCorrected ? " (corrected by a resident)" : " (accepted)"}
              </p>
              {report.signals && (
                <p>
                  <span className="font-semibold text-ink">Detected language:</span>{" "}
                  {report.signals.language.toUpperCase()}
                </p>
              )}
            </div>
            <p className="mt-2 rounded-lg bg-mist/60 px-2.5 py-2 text-[9.5px] leading-relaxed text-ink/45">
              This prototype demonstrates a working classifier and similarity engine. Predictions can
              be wrong; every report is reviewed by people before official action.
            </p>
          </div>

          <div className="rounded-[22px] border border-dashed border-forest/25 bg-lime-soft/50 p-4">
            <p className="text-[11px] font-semibold text-forest">
              Confidence {Math.round(report.aiConfidence * 100)}%
            </p>
            <div className="mt-1.5">
              <ConfidenceMeter value={report.aiConfidence} label="vision + text" compact />
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
