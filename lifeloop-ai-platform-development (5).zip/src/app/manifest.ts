import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "LifeLoop AI — Community Problem Intelligence",
    short_name: "LifeLoop AI",
    description:
      "Small actions. Smart intelligence. Better tomorrow. Report everyday neighbourhood issues, get AI categorization, duplicate detection, and track community fixes.",
    start_url: "/",
    display: "standalone",
    background_color: "#f2f1e8",
    theme_color: "#0b3a2c",
    icons: [
      {
        src: "/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
      },
    ],
  };
}
