import { stat } from "node:fs/promises";
import path from "node:path";
import Link from "next/link";
import { SectionLabel } from "@/components/ui";

export const dynamic = "force-dynamic";

const ZIP_PATH = path.join(
  process.cwd(),
  "public",
  "downloads",
  "lifeloop-ai-website.zip",
);

export default async function DownloadPage() {
  let sizeKb = 0;
  try {
    const info = await stat(ZIP_PATH);
    sizeKb = Math.max(1, Math.round(info.size / 1024));
  } catch {
    sizeKb = 0;
  }

  return (
    <div className="mx-auto max-w-[980px] px-4 py-10 sm:px-6 sm:py-14">
      <SectionLabel>Website source code · GitHub, Vercel &amp; Render</SectionLabel>
      <h1 className="display mt-3 text-[34px] sm:text-[46px]">
        LifeLoop AI website <span className="accent-serif text-forest">in one clean ZIP.</span>
      </h1>
      <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-ink/60">
        A pure, responsive fullstack Next.js website application — works on desktop and mobile
        browsers with zero native app setup. Includes <code className="text-forest">vercel.json</code>,
        serverless-safe PostgreSQL pooling, automatic table &amp; demo-data bootstrap,{" "}
        <code className="text-forest">render.yaml</code>, and GitHub Actions CI.
      </p>

      <div className="mt-7 overflow-hidden rounded-[24px] border border-moss/20 bg-moss p-6 text-paper sm:p-8">
        <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-center">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-lime">
              lifeloop-ai-website.zip {sizeKb > 0 ? `· ${sizeKb} KB` : ""}
            </p>
            <h2 className="display mt-2 text-[24px] sm:text-[28px]">
              Next.js Website + AI Engine + PostgreSQL
            </h2>
            <p className="mt-2 max-w-md text-[12.5px] leading-relaxed text-paper/65">
              Responsive web UI + Web App Manifest, ready to push to GitHub and deploy directly on
              Vercel or Render.
            </p>
          </div>
          <a
            href="/api/download"
            download="lifeloop-ai-website.zip"
            className="inline-flex shrink-0 items-center justify-center gap-2 rounded-full bg-lime px-6 py-3.5 text-[14px] font-bold text-moss transition hover:bg-lime-soft"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2.2} aria-hidden>
              <path d="M12 3v12m0 0 4-4m-4 4-4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Download Website ZIP
          </a>
        </div>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="rounded-[22px] border border-line bg-paper p-5">
          <p className="mono-label">01 · Push to GitHub</p>
          <h3 className="mt-2 text-[17px] font-semibold">Unzip &amp; push the website repo</h3>
          <pre className="mt-3 overflow-x-auto rounded-xl bg-bone p-3 font-mono text-[11px] text-ink/80">
{`unzip lifeloop-ai-website.zip
cd lifeloop-ai-website
git init
git add .
git commit -m "Initial commit: LifeLoop AI website"
git branch -M main
git remote add origin https://github.com/USER/REPO.git
git push -u origin main`}
          </pre>
        </div>

        <div className="rounded-[22px] border border-line bg-paper p-5">
          <p className="mono-label">02 · Deploy on Vercel</p>
          <h3 className="mt-2 text-[17px] font-semibold">Import GitHub repo &amp; attach Postgres</h3>
          <ol className="mt-3 space-y-2 text-[12.5px] leading-relaxed text-ink/65">
            <li>1. Go to <strong>Vercel → Add New… → Project</strong> and import your GitHub repo.</li>
            <li>
              2. In the project&apos;s <strong>Storage</strong> tab, attach a free{" "}
              <strong>Neon Postgres</strong> database (or add <code className="text-forest">DATABASE_URL</code> in Environment Variables).
            </li>
            <li>
              3. Click <strong>Deploy</strong> — <code className="text-forest">vercel.json</code> configures the build, and tables + demo data seed automatically on first visit.
            </li>
          </ol>
        </div>
      </div>

      <div className="mt-4 rounded-[22px] border border-line bg-paper p-5">
        <p className="mono-label">03 · Run locally in your browser</p>
        <pre className="mt-3 overflow-x-auto rounded-xl bg-bone p-3 font-mono text-[11px] text-ink/80">
{`cd lifeloop-ai-website
cp .env.example .env
npm install
npm run dev`}
        </pre>
      </div>

      <div className="mt-6 flex items-center justify-between rounded-2xl border border-line bg-paper px-4 py-3 text-[12px]">
        <span className="text-ink/55">Direct file link: <code className="text-forest">/api/download</code></span>
        <Link href="/dashboard" className="font-semibold text-forest hover:underline">
          Back to dashboard →
        </Link>
      </div>
    </div>
  );
}
