import type { Metadata } from "next";
import type { ReactNode } from "react";
import HeaderClient from "@/components/HeaderClient";
import SiteFooter from "@/components/SiteFooter";
import { getLeaderboard } from "@/lib/data";
import { ensureSeeded } from "@/lib/seed";
import { getCurrentUser } from "@/lib/session";
import type { LeaderRecord } from "@/lib/types";
import "./globals.css";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "LifeLoop AI — Small actions. Smart intelligence. Better tomorrow.",
  description:
    "LifeLoop AI turns everyday community problems into organised, actionable work. Report an issue, let AI detect duplicates, priority and next steps, then track resolution together.",
};

const FALLBACK_USER: LeaderRecord = {
  id: 1,
  name: "Guest neighbour",
  handle: "guest",
  neighbourhood: "Old Town",
  role: "Resident",
  points: 0,
  reportsCount: 0,
  resolvedCount: 0,
  tone: "emerald",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  let user = FALLBACK_USER;
  let members: LeaderRecord[] = [FALLBACK_USER];

  try {
    await ensureSeeded();
    const [current, leaders] = await Promise.all([getCurrentUser(), getLeaderboard()]);
    user = current;
    members = leaders.length ? leaders : [current];
  } catch {
    // Database is still warming up — render the shell without live identity.
  }

  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Instrument+Serif:ital@0;1&family=IBM+Plex+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-bone text-ink antialiased">
        <div className="flex min-h-screen flex-col">
          <HeaderClient user={user} members={members} />
          <main className="flex-1">{children}</main>
          <SiteFooter />
        </div>
      </body>
    </html>
  );
}
