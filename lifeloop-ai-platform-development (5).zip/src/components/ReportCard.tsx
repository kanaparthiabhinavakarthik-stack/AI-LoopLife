/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { CategoryChip, ConfidenceMeter, PriorityBadge, StatusBadge } from "@/components/ui";
import type { ReportRecord } from "@/lib/types";

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const hours = Math.round(diff / 3_600_000);
  if (hours < 1) return "just now";
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return days === 1 ? "1 day ago" : `${days} days ago`;
}

export default function ReportCard({
  report,
  layout = "grid",
}: {
  report: ReportRecord;
  layout?: "grid" | "row";
}) {
  const isGrouped = report.duplicateCount > 0;
  const isDuplicate = report.duplicateOfId != null;

  if (layout === "row") {
    return (
      <Link
        href={`/reports/${report.id}`}
        className="hover-lift group flex gap-3 rounded-2xl border border-line bg-paper p-3"
      >
        <div className="relative h-[74px] w-[74px] shrink-0 overflow-hidden rounded-xl bg-mist">
          {report.imageUrl ? (
            <img src={report.imageUrl} alt="" className="h-full w-full object-cover" loading="lazy" />
          ) : null}
          <span className="absolute bottom-1 left-1 rounded-md bg-ink/75 px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-wide text-lime">
            {report.priority}
          </span>
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="mono-label">{report.reference}</span>
            <span className="text-[10px] text-ink/40">· {timeAgo(report.createdAt)}</span>
          </div>
          <h4 className="mt-1 line-clamp-2 text-[13px] font-semibold leading-snug text-ink group-hover:text-forest">
            {report.title}
          </h4>
          <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
            <StatusBadge status={report.status} />
            <CategoryChip category={report.category} />
            {isGrouped && (
              <span className="rounded-full border border-line bg-mist px-2 py-1 text-[10px] font-medium text-forest">
                {report.duplicateCount} linked
              </span>
            )}
            {isDuplicate && (
              <span className="rounded-full border border-dashed border-forest/30 px-2 py-1 text-[10px] text-ink/50">
                grouped
              </span>
            )}
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      href={`/reports/${report.id}`}
      className="hover-lift group flex flex-col overflow-hidden rounded-[20px] border border-line bg-paper"
    >
      <div className="relative aspect-[16/9] w-full overflow-hidden bg-mist">
        {report.imageUrl ? (
          <img
            src={report.imageUrl}
            alt={report.title}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
            loading="lazy"
          />
        ) : (
          <div className="grid-paper h-full w-full" />
        )}
        <div className="absolute inset-x-0 top-0 flex items-start justify-between p-3">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-ink/80 px-2.5 py-1 font-mono text-[9px] uppercase tracking-[0.14em] text-paper backdrop-blur">
            <span className="h-1 w-1 rounded-full bg-lime" />
            {report.reference}
          </span>
          <PriorityBadge priority={report.priority} />
        </div>
        {isGrouped && (
          <div className="absolute inset-x-3 bottom-3 flex items-center gap-1.5 rounded-lg bg-paper/95 px-2.5 py-1.5 text-[10px] font-semibold text-forest shadow-sm">
            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={1.8} aria-hidden>
              <circle cx="9" cy="9" r="2.5" />
              <circle cx="16" cy="15" r="2.5" />
              <path d="M11 11l3 2" strokeLinecap="round" />
            </svg>
            {report.duplicateCount} duplicate report{report.duplicateCount === 1 ? "" : "s"} merged
          </div>
        )}
      </div>

      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-center gap-2">
          <CategoryChip category={report.category} />
          <span className="text-[10px] text-ink/40">{timeAgo(report.createdAt)}</span>
        </div>
        <h3 className="mt-2.5 line-clamp-2 text-[15px] font-semibold leading-snug tracking-[-0.01em] text-ink group-hover:text-forest">
          {report.title}
        </h3>
        <p className="mt-1.5 flex items-center gap-1 text-[11px] text-ink/50">
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={1.7} aria-hidden>
            <path d="M12 21s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11Z" />
            <circle cx="12" cy="10" r="2.5" />
          </svg>
          {report.neighbourhood}
        </p>

        <div className="mt-auto space-y-3 pt-3.5">
          <ConfidenceMeter value={report.aiConfidence} label="Model confidence" />
          <div className="flex items-center justify-between border-t border-line pt-3">
            <StatusBadge status={report.status} />
            <span className="flex items-center gap-3 font-mono text-[10px] text-ink/45">
              <span className="inline-flex items-center gap-1">
                <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={1.7} aria-hidden>
                  <path d="M7 11v9H4v-9h3Zm0 0 4.2-7.4a2 2 0 0 1 3.6 1.6L14 9h4.5a2 2 0 0 1 2 2.4l-1.3 6.5a2 2 0 0 1-2 1.6H7" />
                </svg>
                {report.upvotes}
              </span>
              <span className="inline-flex items-center gap-1">
                <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={1.8} aria-hidden>
                  <path d="m5 12.5 4.5 4.5L19 7.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                {report.verifications}
              </span>
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
