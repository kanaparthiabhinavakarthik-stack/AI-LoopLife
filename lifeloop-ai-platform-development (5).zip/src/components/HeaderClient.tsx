"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Avatar, Logo } from "@/components/ui";
import type { LeaderRecord } from "@/lib/types";

const LINKS = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/report", label: "Report an issue" },
  { href: "/heatmap", label: "Heatmap" },
  { href: "/impact", label: "Impact" },
  { href: "/download", label: "Download ZIP" },
];

export default function HeaderClient({
  user,
  members,
}: {
  user: LeaderRecord;
  members: LeaderRecord[];
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const [pending, startTransition] = useTransition();

  async function switchUser(id: number) {
    await fetch("/api/session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: id }),
    });
    setMenu(false);
    startTransition(() => router.refresh());
  }

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-bone/85 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-[1180px] items-center justify-between gap-4 px-4 sm:px-6">
        <div className="flex items-center gap-7">
          <Logo />
          <nav className="hidden items-center gap-1 md:flex">
            {LINKS.map((link) => {
              const active = pathname === link.href || pathname.startsWith(`${link.href}/`);
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`rounded-full px-3.5 py-2 text-[13px] font-medium transition ${
                    active
                      ? "bg-white text-ink shadow-[0_1px_0_rgba(13,31,24,0.06)]"
                      : "text-ink/60 hover:bg-white/60 hover:text-ink"
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href="/report"
            className="hidden items-center gap-2 rounded-full bg-forest px-4 py-2 text-[13px] font-semibold text-paper transition hover:bg-moss sm:inline-flex"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-lime pulse-dot" />
            New report
          </Link>

          <div className="relative">
            <button
              type="button"
              onClick={() => setMenu((value) => !value)}
              className="flex items-center gap-2 rounded-full border border-line bg-paper px-1.5 py-1.5 pr-3 transition hover:border-forest/40"
              aria-expanded={menu}
              aria-label="Switch community member"
            >
              <Avatar name={user.name} tone={user.tone} size="sm" />
              <span className="hidden text-left leading-tight sm:block">
                <span className="block text-[11px] font-semibold text-ink">{user.name.split(" ")[0]}</span>
                <span className="block font-mono text-[9px] uppercase tracking-[0.12em] text-ink/45">
                  {user.points} pts
                </span>
              </span>
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 text-ink/40" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
                <path d="m6 9 6 6 6-6" strokeLinecap="round" />
              </svg>
            </button>

            {menu && (
              <>
                <button
                  type="button"
                  aria-label="Close member menu"
                  onClick={() => setMenu(false)}
                  className="fixed inset-0 z-0 cursor-default bg-transparent"
                />
              <div className="absolute right-0 z-10 mt-2 w-72 overflow-hidden rounded-2xl border border-line bg-paper shadow-[0_24px_60px_-30px_rgba(11,58,44,0.5)]">
                <div className="border-b border-line bg-mist/50 px-4 py-3">
                  <p className="mono-label">Demo identity</p>
                  <p className="mt-1 text-xs text-ink/60">
                    Switch residents to test verification, corrections and impact points.
                  </p>
                </div>
                <div className="max-h-72 overflow-y-auto no-scrollbar">
                  {members.map((member) => (
                    <button
                      key={member.id}
                      type="button"
                      onClick={() => switchUser(member.id)}
                      disabled={pending}
                      className={`flex w-full items-center gap-3 px-4 py-2.5 text-left transition hover:bg-mist/60 ${
                        member.id === user.id ? "bg-lime-soft/70" : ""
                      }`}
                    >
                      <Avatar name={member.name} tone={member.tone} size="sm" />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[12px] font-semibold text-ink">
                          {member.name}
                        </span>
                        <span className="block truncate text-[10px] text-ink/50">
                          {member.neighbourhood} · {member.role}
                        </span>
                      </span>
                      <span className="font-mono text-[10px] text-forest">{member.points}</span>
                    </button>
                  ))}
                </div>
              </div>
              </>
            )}
          </div>

          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-line bg-paper md:hidden"
            aria-label="Toggle navigation"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={1.8} aria-hidden>
              {open ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-line bg-paper px-4 py-3 md:hidden">
          <div className="grid gap-1">
            {LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="rounded-xl px-3 py-2.5 text-sm font-medium text-ink/75 hover:bg-mist"
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
