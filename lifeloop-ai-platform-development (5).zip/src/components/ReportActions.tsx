"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { CATEGORIES, type CategoryId, type ReportStatus } from "@/lib/types";

type Props = {
  reportId: number;
  status: ReportStatus;
  category: CategoryId;
  upvotes: number;
  verifications: number;
  reporterName: string | null;
  points: number;
};

const STATUS_FLOW: { id: ReportStatus; label: string }[] = [
  { id: "open", label: "Open" },
  { id: "in_progress", label: "In progress" },
  { id: "resolved", label: "Resolved" },
];

export default function ReportActions({
  reportId,
  status,
  category,
  upvotes,
  verifications,
  reporterName,
  points,
}: Props) {
  const router = useRouter();
  const [busy, setBusy] = useState("");
  const [message, setMessage] = useState<{ tone: "ok" | "error"; text: string } | null>(null);
  const [statusNote, setStatusNote] = useState("");
  const [updateNote, setUpdateNote] = useState("");
  const [selectedStatus, setSelectedStatus] = useState<ReportStatus>(status);
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>(category);

  async function act(action: string, payload: Record<string, unknown> = {}) {
    setBusy(action);
    setMessage(null);
    try {
      const response = await fetch(`/api/reports/${reportId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, ...payload }),
      });
      const data = (await response.json()) as { message?: string; error?: string };
      if (!response.ok) {
        setMessage({ tone: "error", text: data.error ?? "That action could not be completed." });
        return;
      }
      setMessage({ tone: "ok", text: data.message ?? "Updated." });
      router.refresh();
    } catch {
      setMessage({ tone: "error", text: "Network error. Please try again." });
    } finally {
      setBusy("");
    }
  }

  return (
    <div className="space-y-3">
      <div className="rounded-[22px] border border-line bg-paper p-4">
        <p className="mono-label">Community voice</p>
        <div className="mt-2.5 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => act("upvote")}
            disabled={busy !== ""}
            className="group flex flex-col items-start rounded-xl border border-line bg-bone/50 px-3 py-2.5 transition hover:border-forest/40 disabled:opacity-60"
          >
            <span className="flex items-center gap-1.5 text-[11.5px] font-semibold text-ink">
              <svg viewBox="0 0 24 24" className="h-4 w-4 text-forest" fill="none" stroke="currentColor" strokeWidth={1.7} aria-hidden>
                <path d="M7 11v9H4v-9h3Zm0 0 4.2-7.4a2 2 0 0 1 3.6 1.6L14 9h4.5a2 2 0 0 1 2 2.4l-1.3 6.5a2 2 0 0 1-2 1.6H7" />
              </svg>
              Support
            </span>
            <span className="mt-0.5 font-mono text-[17px] font-medium text-ink">{upvotes}</span>
          </button>
          <button
            type="button"
            onClick={() => act("verify")}
            disabled={busy !== ""}
            className="group flex flex-col items-start rounded-xl border border-line bg-bone/50 px-3 py-2.5 transition hover:border-forest/40 disabled:opacity-60"
          >
            <span className="flex items-center gap-1.5 text-[11.5px] font-semibold text-ink">
              <svg viewBox="0 0 24 24" className="h-4 w-4 text-forest" fill="none" stroke="currentColor" strokeWidth={1.9} aria-hidden>
                <path d="m5 12.5 4.5 4.5L19 7.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              I see this too
            </span>
            <span className="mt-0.5 font-mono text-[17px] font-medium text-ink">{verifications}</span>
          </button>
        </div>
        <p className="mt-2 text-[10px] leading-relaxed text-ink/40">
          Each confirmation earns +4 points. {reporterName ?? "The reporter"} earns +2 when a
          neighbour confirms the issue.
        </p>
      </div>

      <div className="rounded-[22px] border border-line bg-paper p-4">
        <p className="mono-label">Track resolution</p>
        <div className="mt-2.5 grid grid-cols-3 gap-1 rounded-xl bg-bone/60 p-1">
          {STATUS_FLOW.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSelectedStatus(item.id)}
              className={`rounded-lg px-1.5 py-1.5 text-[10.5px] font-semibold transition ${
                selectedStatus === item.id
                  ? "bg-forest text-paper shadow-sm"
                  : "text-ink/50 hover:text-ink"
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
        <textarea
          value={statusNote}
          onChange={(event) => setStatusNote(event.target.value)}
          rows={2}
          maxLength={400}
          placeholder="Add a short update (optional) — e.g. crew scheduled for Friday."
          className="mt-2 w-full resize-none rounded-xl border border-line bg-bone/50 px-3 py-2 text-[11.5px] text-ink placeholder:text-ink/35 focus:border-forest/50 focus:bg-white focus:outline-none"
        />
        <button
          type="button"
          onClick={() =>
            act("status", { status: selectedStatus, note: statusNote.trim() || undefined })
          }
          disabled={busy !== "" || selectedStatus === status}
          className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-full bg-moss px-4 py-2.5 text-[11.5px] font-semibold text-paper transition hover:bg-ink disabled:opacity-45"
        >
          {busy === "status" ? "Saving…" : `Mark as ${selectedStatus.replace("_", " ")}`}
        </button>
        {selectedStatus === "resolved" && (
          <p className="mt-1.5 text-[9.5px] leading-relaxed text-ink/45">
            Resolving awards +25 impact points to the reporter and +6 to you. Please only resolve
            what is actually fixed.
          </p>
        )}
      </div>

      <div className="rounded-[22px] border border-line bg-paper p-4">
        <p className="mono-label">Human correction</p>
        <p className="mt-1.5 text-[11px] leading-relaxed text-ink/50">
          If the AI misread this issue, choose the right category. The original prediction is kept.
        </p>
        <select
          value={selectedCategory}
          onChange={(event) => setSelectedCategory(event.target.value as CategoryId)}
          className="mt-2 w-full rounded-xl border border-line bg-bone/50 px-3 py-2.5 text-[12px] font-medium text-ink focus:border-forest/50 focus:outline-none"
        >
          {CATEGORIES.map((item) => (
            <option key={item.id} value={item.id}>
              {item.label}
            </option>
          ))}
        </select>
        <button
          type="button"
          onClick={() => act("category", { category: selectedCategory })}
          disabled={busy !== "" || selectedCategory === category}
          className="mt-2 w-full rounded-full border border-forest/30 px-4 py-2 text-[11.5px] font-semibold text-forest transition hover:bg-lime-soft/60 disabled:opacity-40"
        >
          {busy === "category" ? "Saving…" : "Save correction (+5 pts)"}
        </button>
      </div>

      <div className="rounded-[22px] border border-line bg-paper p-4">
        <div className="flex items-center justify-between">
          <p className="mono-label">Add an update</p>
          <span className="inline-flex items-center gap-1 font-mono text-[9px] uppercase tracking-[0.1em] text-forest">
            <span className="h-1.5 w-1.5 rounded-full bg-lime" /> +{points} thread points
          </span>
        </div>
        <textarea
          value={updateNote}
          onChange={(event) => setUpdateNote(event.target.value)}
          rows={2}
          placeholder="Share what you saw, a photo reference or a crew update."
          className="mt-2 w-full resize-none rounded-xl border border-line bg-bone/50 px-3 py-2 text-[11.5px] text-ink placeholder:text-ink/35 focus:border-forest/50 focus:bg-white focus:outline-none"
        />
        <button
          type="button"
          onClick={() => {
            act("note", { note: updateNote });
            setUpdateNote("");
          }}
          disabled={busy !== "" || !updateNote.trim()}
          className="mt-2 w-full rounded-full bg-forest px-4 py-2.5 text-[11.5px] font-semibold text-paper transition hover:bg-moss disabled:opacity-45"
        >
          {busy === "note" ? "Posting…" : "Post update"}
        </button>
      </div>

      {message && (
        <div
          className={`rounded-xl border px-3 py-2.5 text-[11.5px] ${
            message.tone === "ok"
              ? "border-lime bg-lime-soft/70 text-forest"
              : "border-rose-200 bg-rose-50 text-rose-700"
          }`}
        >
          {message.text}
        </div>
      )}
    </div>
  );
}
