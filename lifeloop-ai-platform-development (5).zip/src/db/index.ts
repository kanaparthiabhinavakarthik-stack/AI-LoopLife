import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

function resolveDatabaseUrl(): string {
  const url =
    process.env.DATABASE_URL ||
    process.env.POSTGRES_URL ||
    process.env.POSTGRES_PRISMA_URL ||
    process.env.POSTGRES_URL_NON_POOLING;

  if (!url) {
    throw new Error(
      "DATABASE_URL (or Vercel POSTGRES_URL) is required. Add a PostgreSQL database in Vercel Storage or set DATABASE_URL.",
    );
  }
  return url;
}

function shouldUseSsl(url: string): boolean {
  if (process.env.DATABASE_SSL === "false") return false;
  if (process.env.DATABASE_SSL === "true") return true;
  if (url.includes("sslmode=require") || url.includes("sslmode=verify-")) return true;
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    const isLocal =
      host === "localhost" ||
      host === "127.0.0.1" ||
      host === "::1" ||
      host.endsWith(".local");
    return !isLocal;
  } catch {
    return false;
  }
}

const globalForDb = globalThis as typeof globalThis & {
  __lifeloopPool?: Pool;
  __lifeloopDb?: ReturnType<typeof drizzle>;
};

export function getPool(): Pool {
  if (!globalForDb.__lifeloopPool) {
    const connectionString = resolveDatabaseUrl();
    const isServerless = Boolean(process.env.VERCEL);
    globalForDb.__lifeloopPool = new Pool({
      connectionString,
      ssl: shouldUseSsl(connectionString) ? { rejectUnauthorized: false } : undefined,
      max: isServerless ? 5 : 10,
      idleTimeoutMillis: isServerless ? 10_000 : 30_000,
      connectionTimeoutMillis: 10_000,
    });
  }
  return globalForDb.__lifeloopPool;
}

export function getDb() {
  if (!globalForDb.__lifeloopDb) {
    globalForDb.__lifeloopDb = drizzle(getPool());
  }
  return globalForDb.__lifeloopDb;
}

// Lazy proxy so importing `@/db` during `next build` on Vercel never throws before runtime env vars load.
export const db: ReturnType<typeof drizzle> = new Proxy({} as ReturnType<typeof drizzle>, {
  get(_target, prop, receiver) {
    const instance = getDb();
    const value = Reflect.get(instance, prop, receiver);
    return typeof value === "function" ? value.bind(instance) : value;
  },
});
